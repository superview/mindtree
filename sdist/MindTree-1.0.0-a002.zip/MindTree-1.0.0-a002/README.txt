Compatibility

MindTree 1.0.0 is compatible with Python 2.5 only.

MindTree uses Tkinter and Tix to build its GUI.  Most standard python
distributions include everything you need to use MindTree.  MindTree is known
to work with the following Python 2.5 distributions with no additional
packages.

   - Windows Distributions of Python from Python.org
   - LINUX Distributions of Python from Python.org
   - All Python distributions from ActiveState.com

MindTree includes a SpellChecker plugin which will not work on a default
install.  If you wish to use the SpellChecker, you must install pyEnchant.
You can find the installer for this package here:  http://pyenchant.sourceforge.net/

Installation

The simplist way to install MindTree is to unzip the archive.

To run, run the MIndTree.py python script.

